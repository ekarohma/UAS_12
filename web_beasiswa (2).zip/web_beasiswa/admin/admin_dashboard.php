<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login_admin.php");
    exit();
}

require '../database/connection.php';
$applications = $conn->query("SELECT * FROM daftar");
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Dashboard Admin</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 font-sans">

<!-- Navbar -->
<nav class="bg-gradient-to-r from-blue-700 to-blue-500 shadow-md">
  <div class="max-w-6xl mx-auto px-4">
    <div class="flex justify-between items-center py-3">
      <!-- Logo dan Judul -->
      <div class="flex items-center space-x-4">
        <img src="../assets/img/logoSi.png" alt="Logo Kampus" class="h-10 rounded" style="filter: drop-shadow(0 -1px 4px rgba(0, 0, 0, 0.4));">
        <span class="text-white font-bold text-lg">DASHBOARD ADMIN - PENDAFTARAN BEASISWA</span>
      </div>

      <!-- Tombol Toggle Mobile -->
      <div class="md:hidden">
        <button id="menu-btn" class="text-white focus:outline-none">
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                  d="M4 6h16M4 12h16M4 18h16"/>
          </svg>
        </button>
      </div>

      <!-- Navigasi Desktop -->
      <ul id="menu" class="hidden md:flex space-x-4 font-bold text-white text-sm">
        <li><a href="../function/logout.php" class="hover:text-gray-200 hover:scale-105 transition-all duration-200">LOGOUT</a></li>
      </ul>
    </div>

    <!-- Navigasi Mobile -->
    <ul id="mobile-menu" class="md:hidden hidden flex-col space-y-2 pb-4 text-white font-bold text-sm">
      <li><a href="../function/logout.php" class="hover:text-gray-200">LOGOUT</a></li>
    </ul>
  </div>
</nav>

<!-- Content -->
<div class="max-w-7xl mx-auto px-4 mt-8">
  <h2 class="text-center text-2xl font-bold text-blue-700 mb-6">Daftar Pendaftar Beasiswa</h2>

  <div class="overflow-x-auto bg-white rounded-lg shadow-md p-4">
    <table class="min-w-full text-sm text-center border border-gray-300">
      <thead class="bg-blue-700 text-white text-xs sm:text-sm">
        <tr>
          <th class="px-3 py-2 border">No.</th>
          <th class="px-3 py-2 border">Nama</th>
          <th class="px-3 py-2 border">Email</th>
          <th class="px-3 py-2 border">Status Ajuan</th>
          <th class="px-3 py-2 border">Tindakan</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($applications->num_rows > 0): ?>
          <?php $no = 1; ?>
          <?php while ($row = $applications->fetch_assoc()): ?>
            <tr class="border-b hover:bg-gray-50">
              <td class="px-3 py-2 border"><?= $no++; ?></td>
              <td class="px-3 py-2 border text-gray-800"><?= htmlspecialchars($row['nama']); ?></td>
              <td class="px-3 py-2 border text-gray-800"><?= htmlspecialchars($row['email']); ?></td>
              <td class="px-3 py-2 border">
                <?php if ($row['status_ajuan'] == '1'): ?>
                  <span class="inline-block px-2 py-1 text-xs font-semibold text-green-800 bg-green-200 rounded-full">Terverifikasi</span>
                <?php else: ?>
                  <span class="inline-block px-2 py-1 text-xs font-semibold text-gray-800 bg-gray-200 rounded-full">Belum</span>
                <?php endif; ?>
              </td>
              <td class="px-3 py-2 border space-y-1 sm:space-x-2 sm:space-y-0 sm:flex sm:justify-center">
                <a href="hapus_ajuan.php?id=<?= $row['id']; ?>"
                   onclick="return confirm('Apakah Anda yakin ingin menghapus pendaftar ini?')"
                   class="inline-block px-3 py-1 text-xs font-medium text-red-700 bg-red-100 border border-red-300 rounded hover:bg-red-200 transition">Hapus</a>
                <a href="verifikasi.php?id=<?= $row['id']; ?>&status=1"
                   class="inline-block px-3 py-1 text-xs font-medium text-blue-700 bg-blue-100 border border-blue-300 rounded hover:bg-blue-200 transition">Verifikasi</a>
                <a href="verifikasi.php?id=<?= $row['id']; ?>&status=0"
                   class="inline-block px-3 py-1 text-xs font-medium text-yellow-700 bg-yellow-100 border border-yellow-300 rounded hover:bg-yellow-200 transition">Batalkan</a>
              </td>
            </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr>
            <td colspan="5" class="text-gray-500 px-4 py-4 border">Belum ada data pendaftar.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
  // Toggle untuk mobile navbar
  document.getElementById('menu-btn').addEventListener('click', function () {
    const mobileMenu = document.getElementById('mobile-menu');
    mobileMenu.classList.toggle('hidden');
  });
</script>

</body>
</html>
