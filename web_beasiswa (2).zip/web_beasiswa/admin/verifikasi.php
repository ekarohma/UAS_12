<?php
session_start();
require '../database/connection.php';

$id = $_GET['id'];
$status = $_GET['status'];

$conn->query("UPDATE daftar SET status_ajuan='$status' WHERE id=$id");
header("Location: admin_dashboard.php");
