<?php
session_start();
require '../database/connection.php';

$errorMessage = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = md5($_POST['password']);

    $query = "SELECT * FROM admin WHERE username='$username' AND password='$password'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $_SESSION['admin'] = $username;
        header("Location: admin_dashboard.php");
        exit();
    } else {
        $errorMessage['general'] = "Username atau password salah!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login Admin - Sistem Beasiswa</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen flex flex-col md:flex-row">

  <!-- Sidebar kiri -->
  <div class="md:w-2/5 w-full bg-gradient-to-b from-[#0F6AC9] to-[#0579F9] text-white flex flex-col items-center justify-center p-8">
    <img src="../assets/img/SI.png" alt="Logo Kampus" class="w-40 md:w-72 mb-6 md:mb-8">
    <h1 class="text-2xl md:text-3xl font-bold text-center mb-3 md:mb-4">Selamat Datang, Admin</h1>
    <p class="text-center text-sm md:text-base font-medium max-w-xs md:max-w-sm">Kelola data pendaftaran beasiswa secara efisien dan aman melalui panel admin.</p>
  </div>

  <!-- Form login kanan -->
  <div class="md:w-3/5 w-full flex items-center justify-center bg-gray-100 p-6">
    <div class="w-full max-w-md">
      <form method="POST" autocomplete="off" class="w-full">
        <h2 class="text-xl md:text-2xl font-semibold text-gray-800 mb-1">Admin Pendaftaran Beasiswa</h2>
        <p class="text-gray-600 text-sm mb-6">Masukkan username dan password Anda untuk masuk.</p>

        <label for="username" class="block text-gray-700 font-medium text-sm mb-1">Username</label>
        <input type="text" name="username" required onblur="validateusername()" placeholder="Masukkan username Anda"
               class="w-full px-4 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-[#0579F9] mb-1">
        <p class="text-red-600 text-sm mb-3" id="usernameError"><?= $errorMessage['username'] ?? '' ?></p>

        <label for="password" class="block text-gray-700 font-medium text-sm mb-1">Password</label>
        <input type="password" name="password" required placeholder="Masukkan Password"
               class="w-full px-4 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-[#0579F9] mb-1">
        <p class="text-red-600 text-sm mb-3"><?= $errorMessage['password'] ?? '' ?></p>

        <?php if (!empty($errorMessage['general'])): ?>
          <p class="text-red-600 text-sm mb-4"><?= $errorMessage['general'] ?></p>
        <?php endif; ?>

        <button type="submit"
                class="w-full bg-[#0579F9] hover:bg-[#0F6AC9] text-white py-2 rounded-full font-semibold transition duration-200">
          Masuk
        </button>

        <div class="text-center mt-4">
          <p class="text-sm text-gray-600">Apakah Anda ingin kembali ke halaman awal? <a href="../index.php" class="text-[#0579F9] font-semibold hover:underline">kembali</a></p>
        </div>
      </form>
    </div>
  </div>

  <script>
    function validateusername() {
      const usernameField = document.querySelector('input[name="username"]');
      const usernameError = document.getElementById('usernameError');
      const username = usernameField.value.trim();

      usernameError.textContent = '';

      if (username === '') {
        usernameField.setCustomValidity('Username tidak boleh kosong');
        usernameField.reportValidity();
      } else {
        usernameField.setCustomValidity('');
      }
    }
  </script>

</body>
</html>
