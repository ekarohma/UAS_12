<?php
session_start();
require '../database/connection.php';

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

$id = $_GET['id'] ?? 0;

// Ambil data berdasarkan ID
$query = $conn->query("SELECT * FROM daftar WHERE id = $id");
if ($query->num_rows == 0) {
    echo "Data tidak ditemukan.";
    exit();
}

$data = $query->fetch_assoc();

// Hapus data jika dikonfirmasi
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $delete = "DELETE FROM daftar WHERE id = $id";
    if ($conn->query($delete)) {
        header("Location: admin_dashboard.php?hapus=berhasil");
        exit();
    } else {
        echo "Gagal menghapus data.";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Hapus Ajuan</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center">

    <div class="bg-white shadow-md rounded-lg p-8 w-full max-w-md">
        <h2 class="text-2xl font-bold text-blue-600 mb-4 text-center">Konfirmasi Hapus Ajuan</h2>
        <p class="text-gray-700 text-center mb-6">Yakin ingin menghapus data pendaftar berikut?</p>

        <div class="mb-4">
            <div class="mb-2">
                <span class="font-semibold">Nama:</span> <?= htmlspecialchars($data['nama']); ?>
            </div>
            <div class="mb-2">
                <span class="font-semibold">Email:</span> <?= htmlspecialchars($data['email']); ?>
            </div>
            <div class="mb-2">
                <span class="font-semibold">IPK Terakhir:</span> <?= htmlspecialchars($data['last_ipk']); ?>
            </div>
        </div>

        <form method="post" class="flex justify-between mt-6">
            <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2 rounded">
                Ya, Hapus
            </button>
            <a href="admin_dashboard.php" class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-semibold px-4 py-2 rounded">
                Batal
            </a>
        </form>
    </div>

</body>
</html>
