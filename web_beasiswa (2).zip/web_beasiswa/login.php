<?php
session_start();
require 'database/connection.php';

if (isset($_SESSION['nama'])) {
    header("Location: page/dashboard.php");
    exit();
}

$errorMessage = [
    'email' => '',
    'password' => '',
    'general' => ''
];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $query->bind_param("s", $email);
    $query->execute();
    $resultSet = $query->get_result();

    if ($resultSet->num_rows > 0) {
        $userData = $resultSet->fetch_assoc();
        if (password_verify($password, $userData['password'])) {
            $_SESSION['nama'] = $userData['nama'];
            header("Location: page/dashboard.php");
            exit();
        } else {
            $errorMessage['password'] = "Password yang Anda masukkan salah.";
        }
    } else {
        $errorMessage['email'] = "Pengguna tidak ditemukan.";
    }

    $query->close();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login Beasiswa</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    function validateEmail() {
      const emailField = document.querySelector('input[name="email"]');
      const email = emailField.value.trim();
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(email)) {
        emailField.setCustomValidity('Email harus mengandung karakter @');
        emailField.reportValidity();
      } else {
        emailField.setCustomValidity('');
      }
    }
  </script>
</head>
<body class="bg-gray-100 font-sans">

  <!-- Navbar -->
  <nav class="bg-[linear-gradient(to_right,#0F6AC9,#0579F9)] shadow-md">
    <div class="max-w-6xl mx-auto px-4 flex items-center h-14">
      <img src="assets/img/logoSi.png" alt="Logo Kampus" class="h-10 rounded" style="filter: drop-shadow(0 -1px 4px rgba(0, 0, 0, 0.4));">
      <span class="text-white font-bold text-sm md:text-base ml-3">
        PLATFORM BEASISWA SISTEM INFORMASI
      </span>
    </div>
  </nav>

  <h1 class="text-center text-xl text-[#0F6AC9] font-semibold mt-6 mb-4">
    Masuk ke Akun Beasiswa
  </h1>

  <?php if (!empty($errorMessage['general'])): ?>
    <p class="text-red-600 text-center font-medium"><?= $errorMessage['general'] ?></p>
  <?php endif; ?>

  <form method="POST" autocomplete="off" class="max-w-md mx-auto bg-white p-6 rounded-lg shadow-md mt-4">
    <label for="email" class="block font-semibold mb-2 text-gray-700">Email</label>
    <input type="email" name="email" required onblur="validateEmail()" class="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-[#0F6AC9]">
    <p class="text-red-500 text-sm mt-1"><?= $errorMessage['email'] ?></p>

    <label for="password" class="block mt-4 font-semibold mb-2 text-gray-700">Password</label>
    <input type="password" name="password" required class="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-[#0F6AC9]">
    <p class="text-red-500 text-sm mt-1"><?= $errorMessage['password'] ?></p>

    <button type="submit" class="w-full bg-[linear-gradient(to_right,#0F6AC9,#0579F9)] text-white py-2 mt-6 rounded-md hover:shadow-lg transition-all">
      Masuk
    </button>
  </form>

  <div class="text-center mt-4">
    <p class="text-gray-700">Belum memiliki akun?
      <a href="index.php" class="text-[#0F6AC9] underline hover:text-[#0579F9]">Daftar di sini</a>
    </p>
  </div>

</body>
</html>
