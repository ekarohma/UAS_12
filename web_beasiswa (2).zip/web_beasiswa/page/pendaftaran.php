<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $noHp = $_POST['noHp'];
    $nim = $_POST['nim_mhs'];
    $semester = $_POST['semester'];
    $ipk = $_POST['last_ipk'];
    $beasiswa = $_POST['beasiswa'];

    $uploadDir = '../uploads/';
    $berkasName = basename($_FILES["berkas"]["name"]);
    $fileName = time() . "_" . $berkasName;
    $targetFile = $uploadDir . $fileName;
    $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    $allowedTypes = ["pdf", "doc", "docx"];
    $uploadSuccess = false;

    if (in_array($fileType, $allowedTypes)) {
        if (move_uploaded_file($_FILES["berkas"]["tmp_name"], $targetFile)) {
            $uploadSuccess = true;
        }
    }

    if ($uploadSuccess) {
        require '../database/connection.php'; // Pastikan file ini konek DB

        $query = "INSERT INTO daftar (nama, email, no_hp, nim_mhs, semester, last_ipk, beasiswa, syarat_berkas, status_ajuan)
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sssssdss", $nama, $email, $noHp, $nim, $semester, $ipk, $beasiswa, $fileName);

        if ($stmt->execute()) {
            echo "<script>alert('Pendaftaran berhasil!'); window.location.href='hasil.php';</script>";
        } else {
            echo "<script>alert('Gagal menyimpan data ke database');</script>";
        }

        $stmt->close();
        $conn->close();
    } else {
        echo "<script>alert('Gagal mengunggah berkas. Pastikan format file benar dan folder uploads tersedia.');</script>";
    }
}
?>

<!-- HTML form-nya tetap seperti yang kamu punya, tidak perlu diubah -->


<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Form Pendaftaran Beasiswa</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 font-sans">

  <!-- Navbar -->
  <nav class="bg-gradient-to-r from-blue-700 to-blue-500 shadow-md">
    <div class="max-w-6xl mx-auto px-4">
      <div class="flex justify-between items-center py-3">
        <div class="flex items-center space-x-4">
          <img src="../assets/img/logoSi.png" alt="Logo Kampus" class="h-10 rounded" style="filter: drop-shadow(0 -1px 4px rgba(0, 0, 0, 0.4));">
          <span class="text-white font-bold text-lg">PENDAFTARAN BEASISWA</span>
        </div>
        <div class="md:hidden">
          <button id="menu-btn" class="text-white focus:outline-none">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M4 6h16M4 12h16M4 18h16"/>
            </svg>
          </button>
        </div>
        <ul id="menu" class="hidden md:flex space-x-4 font-bold text-white text-sm">
          <li><a href="dashboard.php" class="hover:text-gray-200 hover:scale-105 transition-all duration-200">KATEGORI BEASISWA</a></li>
          <li><a href="pendaftaran.php" class="hover:text-gray-200 hover:scale-105 transition-all duration-200">DAFTAR BEASISWA</a></li>
          <li><a href="hasil.php" class="hover:text-gray-200 hover:scale-105 transition-all duration-200">HASIL</a></li>
          <li><a href="../function/logout.php" class="hover:text-gray-200 hover:scale-105 transition-all duration-200">LOGOUT</a></li>
        </ul>
      </div>
      <ul id="mobile-menu" class="md:hidden hidden flex-col space-y-2 pb-4 text-white font-bold text-sm">
        <li><a href="dashboard.php" class="hover:text-gray-200">KATEGORI BEASISWA</a></li>
        <li><a href="pendaftaran.php" class="hover:text-gray-200">DAFTAR BEASISWA</a></li>
        <li><a href="hasil.php" class="hover:text-gray-200">HASIL</a></li>
        <li><a href="../function/logout.php" class="hover:text-gray-200">LOGOUT</a></li>
      </ul>
    </div>
  </nav>

  <!-- Form -->
  <div class="max-w-5xl mx-auto mt-10 p-6 bg-white rounded-lg shadow-md">
    <h2 class="text-2xl font-bold text-blue-600 mb-6">Form Pendaftaran</h2>
    <form action="" method="POST" enctype="multipart/form-data" onsubmit="return validateForm()" class="space-y-6">
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label class="block mb-1 font-semibold">Nama</label>
          <input type="text" name="nama" required class="w-full border border-gray-300 rounded px-4 py-2">

          <label class="block mt-4 mb-1 font-semibold">Email</label>
          <input type="email" name="email" required class="w-full border border-gray-300 rounded px-4 py-2">

          <label class="block mt-4 mb-1 font-semibold">No. HP</label>
          <input type="tel" name="noHp" pattern="[0-9]+" required class="w-full border border-gray-300 rounded px-4 py-2">

          <label class="block mt-4 mb-1 font-semibold">NIM Mahasiswa</label>
          <input type="text" name="nim_mhs" required pattern="[0-9]+" class="w-full border border-gray-300 rounded px-4 py-2">
        </div>

        <div>
          <label class="block mb-1 font-semibold">Semester Saat Ini</label>
          <select name="semester" required class="w-full border border-gray-300 rounded px-4 py-2">
            <option value="" disabled selected>Pilih Semester</option>
            <?php for ($i = 1; $i <= 8; $i++): ?>
              <option value="<?= $i ?>">Semester <?= $i ?></option>
            <?php endfor; ?>
          </select>

          <label class="block mt-4 mb-1 font-semibold">IPK Terakhir</label>
          <input type="text" name="last_ipk" list="ipkList" placeholder="Pilih atau ketik IPK" required class="w-full border border-gray-300 rounded px-4 py-2">
          <datalist id="ipkList">
            <?php for ($i = 0.00; $i <= 4.00; $i += 0.01): ?>
              <option value="<?= number_format($i, 2) ?>">
            <?php endfor; ?>
          </datalist>

          <label class="block mt-4 mb-1 font-semibold">Pilih Beasiswa</label>
          <select name="beasiswa" required class="w-full border border-gray-300 rounded px-4 py-2">
            <option value="" disabled selected>Pilih Beasiswa</option>
            <option value="akademik">Beasiswa Akademik</option>
            <option value="non-akademik">Beasiswa Non-Akademik</option>
          </select>

          <label class="block mt-4 mb-1 font-semibold">Upload Berkas Syarat</label>
          <input type="file" name="berkas" accept=".pdf,.doc,.docx" required class="w-full border border-gray-300 rounded px-4 py-2">
          <p class="text-sm text-gray-500 mt-1">*Gabungkan semua berkas ke dalam satu file (pdf/doc/docx).</p>
        </div>
      </div>

      <div class="flex justify-between mt-6">
        <button type="reset" class="bg-gray-400 text-white px-6 py-2 rounded hover:bg-gray-500">Batal</button>
        <button type="submit" name="submit" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">Daftar</button>
      </div>
    </form>
  </div>

  <!-- Validasi Form JS -->
  <script>
    function validateForm() {
      const ipk = parseFloat(document.querySelector('input[name="last_ipk"]').value);
      const nim = document.querySelector('input[name="nim_mhs"]').value;

      if (isNaN(ipk) || ipk < 0 || ipk > 4) {
        alert("IPK harus antara 0.00 hingga 4.00");
        return false;
      }

      if (!/^\d+$/.test(nim)) {
        alert("NIM hanya boleh berisi angka");
        return false;
      }

      return true;
    }

    document.getElementById('menu-btn').addEventListener('click', () => {
      document.getElementById('mobile-menu').classList.toggle('hidden');
    });
  </script>

</body>
</html>
