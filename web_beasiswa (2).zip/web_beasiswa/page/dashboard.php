<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Dashboard Beasiswa</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 font-sans text-gray-800">

  <!-- Navbar -->
  <nav class="bg-gradient-to-r from-blue-700 to-blue-500 shadow-md">
    <div class="max-w-6xl mx-auto px-4">
      <div class="flex justify-between items-center py-3">
        <!-- Logo and Title -->
        <div class="flex items-center space-x-4">
          <img src="../assets/img/logoSi.png" alt="Logo Kampus" class="h-10 rounded" style="filter: drop-shadow(0 -1px 4px rgba(0, 0, 0, 0.4));">
          <span class="text-white font-bold text-lg">PENDAFTARAN BEASISWA</span>
        </div>

        <!-- Mobile toggle button -->
        <div class="md:hidden">
          <button id="menu-btn" class="text-white focus:outline-none">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M4 6h16M4 12h16M4 18h16"/>
            </svg>
          </button>
        </div>

        <!-- Desktop Navigation -->
        <ul id="menu" class="hidden md:flex space-x-4 font-bold text-white text-sm">
          <li><a href="dashboard.php" class="hover:text-gray-200 hover:scale-105 transition-all duration-200">KATEGORI BEASISWA</a></li>
          <li><a href="pendaftaran.php" class="hover:text-gray-200 hover:scale-105 transition-all duration-200">DAFTAR BEASISWA</a></li>
          <li><a href="hasil.php" class="hover:text-gray-200 hover:scale-105 transition-all duration-200">HASIL</a></li>
          <li><a href="../function/logout.php" class="hover:text-gray-200 hover:scale-105 transition-all duration-200">LOGOUT</a></li>
        </ul>
      </div>

      <!-- Mobile Navigation -->
      <ul id="mobile-menu" class="md:hidden hidden flex-col space-y-2 pb-4 text-white font-bold text-sm">
        <li><a href="dashboard.php" class="hover:text-gray-200">KATEGORI BEASISWA</a></li>
        <li><a href="pendaftaran.php" class="hover:text-gray-200">DAFTAR BEASISWA</a></li>
        <li><a href="hasil.php" class="hover:text-gray-200">HASIL</a></li>
        <li><a href="../function/logout.php" class="hover:text-gray-200">LOGOUT</a></li>
      </ul>
    </div>
  </nav>

  <!-- Main Section -->
  <section class="max-w-6xl mx-auto my-10 p-6 bg-white rounded-lg shadow-md">
    <h1 class="text-2xl font-bold text-center text-black mb-2">Selamat Datang, <?php echo $_SESSION['nama']; ?>!</h1>
    <h2 class="text-blue-600 text-lg text-center mb-6">Daftar beasiswa sesuai dengan pilihanmu sekarang!</h2>

    <!-- Scholarship Cards -->
    <div class="grid gap-6 grid-cols-1 md:grid-cols-2">
      <!-- Akademik -->
      <a href="../page/akademik.php" class="block text-inherit no-underline">
        <div class="bg-white border border-gray-300 rounded-xl shadow hover:shadow-lg transition-all duration-300 overflow-hidden h-full">
          <img src="../assets/img/akademik.jpg" alt="Beasiswa Akademik" class="w-full h-48 object-cover">
          <div class="p-4">
            <h4 class="text-xl font-semibold text-blue-600 mb-2">Beasiswa Akademik</h4>
            <p class="text-sm text-gray-700 leading-relaxed">
              <strong>Syarat:</strong> Memiliki IPK minimal 3.0 dan aktif berpartisipasi dalam kegiatan ilmiah.
            </p>
          </div>
        </div>
      </a>

      <!-- Non-Akademik -->
      <a href="../page/non_akademik.php" class="block text-inherit no-underline">
        <div class="bg-white border border-gray-300 rounded-xl shadow hover:shadow-lg transition-all duration-300 overflow-hidden h-full">
          <img src="../assets/img/non-akademik.jpg" alt="Beasiswa Non-Akademik" class="w-full h-48 object-cover">
          <div class="p-4">
            <h4 class="text-xl font-semibold text-blue-600 mb-2">Beasiswa Non-Akademik</h4>
            <p class="text-sm text-gray-700 leading-relaxed">
              <strong>Syarat:</strong> Memiliki IPK minimum 3.0, serta berprestasi dalam kegiatan non-akademik, seperti olahraga dan seni.
            </p>
          </div>
        </div>
      </a>
    </div>
  </section>

  <!-- Script: Toggle Mobile Menu -->
  <script>
    const menuBtn = document.getElementById('menu-btn');
    const mobileMenu = document.getElementById('mobile-menu');

    menuBtn.addEventListener('click', () => {
      mobileMenu.classList.toggle('hidden');
    });
  </script>

</body>
</html>
