<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Pendaftaran Beasiswa Akademik</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 text-gray-800">

  <!-- Navbar -->
  <nav class="bg-gradient-to-r from-blue-700 to-blue-500 shadow-md">
    <div class="max-w-6xl mx-auto px-4">
      <div class="flex justify-between items-center py-3">
        
        <!-- Logo and Title -->
        <div class="flex items-center space-x-4">
          <img src="../assets/img/logoSi.png" alt="Logo Kampus" class="h-10 rounded" style="filter: drop-shadow(0 -1px 4px rgba(0, 0, 0, 0.4));">
          <span class="text-white font-bold text-lg">PENDAFTARAN BEASISWA</span>
        </div>
      <div class="md:hidden">
        <button id="menu-btn" class="text-white">
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                  d="M4 6h16M4 12h16M4 18h16"/>
          </svg>
        </button>
      </div>
      <ul class="hidden md:flex space-x-4 text-sm font-bold text-white">
        <li><a href="dashboard.php" class="hover:text-gray-200 transition">KATEGORI BEASISWA</a></li>
        <li><a href="pendaftaran.php" class="hover:text-gray-200 transition">DAFTAR BEASISWA</a></li>
        <li><a href="hasil.php" class="hover:text-gray-200 transition">HASIL</a></li>
        <li><a href="../function/logout.php" class="hover:text-gray-200 transition">LOGOUT</a></li>
      </ul>
    </div>
    <ul id="mobile-menu" class="md:hidden hidden flex-col px-4 pb-4 space-y-2 text-white font-bold text-sm">
      <li><a href="dashboard.php" class="hover:text-gray-200">KATEGORI BEASISWA</a></li>
      <li><a href="pendaftaran.php" class="hover:text-gray-200">DAFTAR BEASISWA</a></li>
      <li><a href="hasil.php" class="hover:text-gray-200">HASIL</a></li>
      <li><a href="../function/logout.php" class="hover:text-gray-200">LOGOUT</a></li>
    </ul>
  </nav>

  <!-- Header -->
  <header class="text-center py-6">
    <h1 class="text-2xl md:text-3xl font-bold text-blue-700">Beasiswa Akademik</h1>
  </header>

  <!-- Main Content -->
  <main class="max-w-6xl mx-auto px-4 py-8 bg-gray-100">
    <div class="flex flex-col md:flex-row md:space-x-8 mb-10">
      <div class="md:w-1/2 mb-6 md:mb-0">
        <img src="../assets/img/akademik.jpg" alt="Beasiswa Akademik" class="w-full rounded-lg shadow">
      </div>
      <div class="md:w-1/2 space-y-4">
        <h2 class="text-xl font-bold text-blue-700">Persyaratan Pendaftaran</h2>
        <p><strong>Syarat:</strong> Memiliki IPK minimal 3.0 dan aktif berpartisipasi dalam kegiatan ilmiah.</p>
        <p><strong>Dokumen yang Diperlukan:</strong></p>
        <ul class="list-disc list-inside space-y-1">
          <li>Fotokopi Kartu Tanda Mahasiswa (KTM)</li>
          <li>Transkrip Nilai dari Kartu Hasil Studi (KHS)</li>
          <li>Surat Rekomendasi dari Dosen Pembimbing Akademik</li>
          <li>Sertifikat Pendukung</li>
        </ul>
        <h2 class="text-xl font-bold text-blue-700 mt-4">Manfaat Beasiswa</h2>
        <ul class="list-disc list-inside space-y-1">
          <li>Pembebasan UKT</li>
          <li>Biaya hidup sebesar Rp800.000 per bulan</li>
        </ul>
        <h2 class="text-xl font-bold text-blue-700 mt-4">Informasi Kontak</h2>
        <p>Untuk informasi lebih lanjut, silakan hubungi <strong>admin@beasiswaSI.ac.id</strong>.</p>
      </div>
    </div>

    <!-- Ringkasan dan Grafik -->
    <div class="flex flex-col md:flex-row md:space-x-8">
      <div class="md:w-1/2 mb-8 md:mb-0">
        <h2 class="text-xl font-bold text-blue-700 mb-2">Ringkasan Penerima Beasiswa</h2>
        <p class="mb-2">Beasiswa ini ditujukan bagi mahasiswa yang menunjukkan prestasi tinggi di bidang akademik. Setiap pendaftar harus memenuhi kriteria yang telah ditetapkan dan akan melalui proses seleksi yang ketat.</p>
        <p>Penerima beasiswa akan mendapatkan dukungan biaya pendidikan untuk satu tahun akademik, dengan kemungkinan diperpanjang.</p>
      </div>
      <div class="md:w-1/2">
        <h3 class="text-lg font-bold text-blue-700 mb-2">Data Pendaftar Beasiswa</h3>
        <canvas id="scholarshipChart"></canvas>
      </div>
    </div>
  </main>

  <!-- Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script>
    const ctx = document.getElementById('scholarshipChart').getContext('2d');
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['2022', '2023', '2024', '2025'],
        datasets: [{
          label: 'Jumlah Pendaftar Beasiswa',
          data: [60, 80, 120, 150],
          backgroundColor: 'rgba(57, 117, 214, 0.6)',
          borderColor: 'rgb(37, 123, 194)',
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        scales: {
          y: { beginAtZero: true }
        }
      }
    });
  </script>

  <!-- Mobile Menu Script -->
  <script>
    document.getElementById('menu-btn').addEventListener('click', () => {
      document.getElementById('mobile-menu').classList.toggle('hidden');
    });
  </script>
</body>
</html>
