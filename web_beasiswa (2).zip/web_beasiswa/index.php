<?php
session_start();

// Koneksi ke database
require 'database/connection.php';

// Inisialisasi variabel untuk error
$errorMessage = [
    'email' => '',
    'password' => '',
    'general' => ''
];

// Proses pendaftaran saat form dikirim
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nama = $conn->real_escape_string(trim($_POST['nama']));
    $email = $conn->real_escape_string(trim($_POST['email']));
    $hashedPassword = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Periksa apakah email sudah terdaftar
    $result = $conn->query("SELECT * FROM users WHERE email='$email'");
    
    if ($result && $result->num_rows > 0) {
        $errorMessage['email'] = "Email ini sudah terdaftar, silakan gunakan email lain.";
    } else {
        $insertQuery = "INSERT INTO users (nama, email, password) VALUES ('$nama', '$email', '$hashedPassword')";
        if ($conn->query($insertQuery) === TRUE) {
            header("Location: login.php");
            exit();
        } else {
            $errorMessage['general'] = "Registrasi gagal, silakan coba lagi.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Pendaftaran - Beasiswa</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-white font-sans">
  <div class="min-h-screen grid grid-cols-1 md:grid-cols-2">
    <!-- Gambar Kiri -->
    <div class="bg-[#0F6AC9] flex flex-col items-center justify-center text-center p-8 text-white">
        <img src="assets/img/gambar1.png" alt="Woman Learning" class="max-w-full h-auto">
        <h1 class="text-2xl font-bold mb-4">Selamat Datang di Sistem Pendaftaran Beasiswa</h1>
        <p class="text-lg font-medium">Belajar Lebih Baik, Wujudkan Impianmu!</p>
    </div>

    <!-- Form Kanan -->
    <div class="flex items-center justify-center p-10">
      <div class="w-full max-w-md space-y-6">
        <div class="flex items-center space-x-4 mb-6">
          <img src="assets/img/logoSi.png" alt="Logo Kampus" class="w-16 h-16 object-contain drop-shadow-[0_4px_8px_rgba(0,0,0,0.4)]" />
          <div>
            <h2 class="text-2xl font-semibold text-gray-800">Daftar untuk Akun Beasiswa</h2>
            <p class="text-sm text-gray-500">Lengkapi form untuk mendaftar dan mulai perjalanan akademikmu.</p>
          </div>
        </div>

        <form class="space-y-4" method="POST" autocomplete="off">
          <div>
            <label class="text-sm font-medium text-gray-700">Nama Lengkap</label>
            <input type="text" name="nama" placeholder="Masukkan Nama Lengkap Anda" required class="mt-1 w-full px-4 py-2 border rounded-full focus:outline-none focus:ring-2 focus:ring-[#0F6AC9]">
          </div>

          <div>
            <label class="text-sm font-medium text-gray-700">Alamat Email</label>
            <input type="email" name="email" placeholder="Masukkan Alamat Email Anda" required onblur="validateEmail()" class="mt-1 w-full px-4 py-2 border rounded-full focus:outline-none focus:ring-2 focus:ring-[#0F6AC9]">
            <p class="text-sm text-red-500" id="emailError"><?php echo $errorMessage['email']; ?></p>
          </div>

          <div>
            <label class="text-sm font-medium text-gray-700">Password</label>
            <input type="password" name="password" placeholder="Masukkan Password Anda" required onblur="validatePassword()" class="mt-1 w-full px-4 py-2 border rounded-full focus:outline-none focus:ring-2 focus:ring-[#0F6AC9]">
          </div>

          <?php if (!empty($errorMessage['general'])): ?>
            <p class="text-sm text-red-500"><?php echo $errorMessage['general']; ?></p>
          <?php endif; ?>

          <button type="submit" class="w-full bg-[#0F6AC9] hover:bg-[#0579F9] text-white py-2 rounded-full font-medium">Daftar</button>

          <p class="text-center text-sm mt-4 font-medium">
            Sudah punya akun? <a href="login.php" class="text-[#0F6AC9] hover:underline">Masuk sebagai Pengguna</a><br>
            Atau mau masuk sebagai <a href="admin/login_admin.php" class="text-[#0F6AC9] hover:underline">Admin</a>?
          </p>
        </form>
      </div>
    </div>
  </div>

  <script>
    function validateEmail() {
      const emailField = document.querySelector('input[name="email"]');
      const emailError = document.getElementById('emailError');
      const email = emailField.value.trim();

      emailError.textContent = '';

      if (!email.includes('@')) {
        emailField.setCustomValidity('Email harus mengandung karakter @');
        emailField.reportValidity();
        return;
      } else {
        emailField.setCustomValidity('');
      }

      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(email)) {
        emailError.textContent = 'Email tidak valid.';
        return;
      }

      fetch('check_email.php?email=' + encodeURIComponent(email))
        .then(response => response.json())
        .then(data => {
          if (data.exists) {
            emailError.textContent = 'Email ini sudah terdaftar, silakan gunakan email lain.';
          }
        })
        .catch(error => console.error('Error:', error));
    }

    function validatePassword() {
      const passwordField = document.querySelector('input[name="password"]');
      const password = passwordField.value;

      if (password.length < 8) {
        passwordField.setCustomValidity('Password harus mengandung minimal 8 karakter');
        passwordField.reportValidity();
      } else {
        passwordField.setCustomValidity('');
      }
    }
  </script>
</body>
</html>